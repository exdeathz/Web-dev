<footer class="page-footer">
         <div class="container footer-info">
           <div class="row">
             <div class="col s12 l4 ">
               <ul>
                 <li><a class="grey-text text-lighten-3 animated slideInUp wow" href="#top">На верх</a></li>
                 <li><a class="grey-text text-lighten-3 animated slideInUp wow" href="index">Домой</a></li>
               </ul>
             </div>
             <div class="col s12 l4 ">
               <ul>
                 <li><a class="grey-text text-lighten-3 animated slideInUp wow" href="sign">Зарегестрироваться</a></li>
                 <li><a class="grey-text text-lighten-3 animated slideInUp wow" href="404">Реклама в магазине</a></li>
                 <li><a class="grey-text text-lighten-3 animated slideInUp wow" href="category">СмартФон</a></li>
                 <li><a class="grey-text text-lighten-3 animated slideInUp wow" href="category">СмартКамера</a></li>
               </ul>
             </div>

             <div class="col s12 l4 ">
               <ul>
                 <li><a class="grey-text text-lighten-3 animated slideInUp wow" href="category">СмартЛэптопы</a></li>
                 <li><a class="grey-text text-lighten-3 animated slideInUp wow" href="category">СмартЧасы</a></li>
                 <li><a class="grey-text text-lighten-3 animated slideInUp wow" href="category">СмартДинамик</a></li>
                 <li><a class="grey-text text-lighten-3 animated slideInUp wow" href="category">СмартВиртуалка</a></li>
               </ul>
             </div>
           </div>
         </div>
         <div class="footer-copyright">
           <div class="container">
           © <?= Date('Y'); ?>
           <a class="grey-text text-lighten-4 right animated slideInUp wow" href="http://vk.com/leavemea10ne"> <i class="fa fa-heartbeat animated pulse infinite red-text"></i> Aidar.T</a>
           </div>
         </div>
       </footer>
