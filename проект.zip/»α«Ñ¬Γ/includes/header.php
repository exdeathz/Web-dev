<!DOCTYPE html>
<html>
  <head>
    <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title>СмартШоп</title>   
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>    
      <link rel="stylesheet" href="src/css/font-awesome-4.6.3/css/font-awesome.min.css">  
      <link type="text/css" rel="stylesheet" href="src/css/materialize.min.css"  media="screen,projection"/>
      <link rel="stylesheet" href="src/css/animate.css-master/animate.min.css">
      <link rel="stylesheet" href="src/css/style.css">
      <link rel='stylesheet' href='src/css/nprogress.css'/>
    </head>
  <body>
