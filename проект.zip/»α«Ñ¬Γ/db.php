<?php

$connection = mysqli_connect('localhost', 'root', '', 'smartshop');  
 if(!$connection) {
     die("Database connection failed");
 }

 ?>
